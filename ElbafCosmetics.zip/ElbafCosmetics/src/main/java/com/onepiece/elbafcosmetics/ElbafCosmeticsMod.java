package com.onepiece.elbafcosmetics;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLLoader;

/**
 * DEPENDENT addon for "Mine Piece". This mod refuses to initialize if
 * Mine Piece is not present, in two independent ways:
 *   1) mods.toml declares a mandatory dependency on modId "minepiece",
 *      so Forge itself will show a "missing dependency" screen and
 *      refuse to start the game with this jar in the mods folder.
 *   2) as a belt-and-braces runtime check (in case the mods.toml
 *      dependency is ever bypassed), the constructor below throws if
 *      Mine Piece isn't on the loaded mod list.
 */
@Mod(ElbafCosmeticsMod.MODID)
public class ElbafCosmeticsMod {
    public static final String MODID = "elbafcosmetics";
    private static final String REQUIRED_MOD_ID = "minepiece";

    public ElbafCosmeticsMod() {
        if (!ModList.get().isLoaded(REQUIRED_MOD_ID)) {
            throw new IllegalStateException(
                "[Elbaf Cosmetics] Требуется установленный мод 'Mine Piece' "
                + "(modId=\"" + REQUIRED_MOD_ID + "\"). Без него этот аддон не запускается."
            );
        }

        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modEventBus);
        ModCreativeTab.TABS.register(modEventBus);
    }
}
