package com.onepiece.elbafcosmetics;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.EnumMap;
import java.util.List;
import java.util.function.Supplier;

/**
 * One cosmetic-tier armor material per character set.
 * Defense values are intentionally low (leather-like) since these
 * are cosmetic outfits, not endgame combat gear.
 */
public enum ModArmorMaterials implements ArmorMaterial {

    VEGAPUNK("elbafcosmetics:vegapunk", 15, new int[]{2, 5, 4, 2}, 12,
            SoundEvents.ARMOR_EQUIP_LEATHER, 0.5f, 0.0f),

    LOKI("elbafcosmetics:loki", 15, new int[]{2, 5, 4, 2}, 12,
            SoundEvents.ARMOR_EQUIP_LEATHER, 0.5f, 0.0f),

    HAJRUDIN("elbafcosmetics:hajrudin", 15, new int[]{2, 5, 4, 2}, 12,
            SoundEvents.ARMOR_EQUIP_LEATHER, 0.5f, 0.0f),

    SAUL("elbafcosmetics:saul", 15, new int[]{2, 5, 4, 2}, 12,
            SoundEvents.ARMOR_EQUIP_LEATHER, 0.5f, 0.0f),

    LUFFY_ELBAF("elbafcosmetics:luffy_elbaf", 15, new int[]{2, 5, 4, 2}, 12,
            SoundEvents.ARMOR_EQUIP_LEATHER, 0.5f, 0.0f),

    HARALD("elbafcosmetics:harald", 15, new int[]{2, 5, 4, 2}, 12,
            SoundEvents.ARMOR_EQUIP_LEATHER, 0.5f, 0.0f),

    ZORO_ELBAF("elbafcosmetics:zoro_elbaf", 15, new int[]{2, 5, 4, 2}, 12,
            SoundEvents.ARMOR_EQUIP_LEATHER, 0.5f, 0.0f),

    NAMI_ELBAF("elbafcosmetics:nami_elbaf", 15, new int[]{2, 5, 4, 2}, 12,
            SoundEvents.ARMOR_EQUIP_LEATHER, 0.5f, 0.0f),

    ROBIN_ELBAF("elbafcosmetics:robin_elbaf", 15, new int[]{2, 5, 4, 2}, 12,
            SoundEvents.ARMOR_EQUIP_LEATHER, 0.5f, 0.0f),

    CHOPPER_ELBAF("elbafcosmetics:chopper_elbaf", 15, new int[]{2, 5, 4, 2}, 12,
            SoundEvents.ARMOR_EQUIP_LEATHER, 0.5f, 0.0f),

    USOPP_ELBAF("elbafcosmetics:usopp_elbaf", 15, new int[]{2, 5, 4, 2}, 12,
            SoundEvents.ARMOR_EQUIP_LEATHER, 0.5f, 0.0f),

    SANJI_ELBAF("elbafcosmetics:sanji_elbaf", 15, new int[]{2, 5, 4, 2}, 12,
            SoundEvents.ARMOR_EQUIP_LEATHER, 0.5f, 0.0f),

    FRANKY_ELBAF("elbafcosmetics:franky_elbaf", 15, new int[]{2, 5, 4, 2}, 12,
            SoundEvents.ARMOR_EQUIP_LEATHER, 0.5f, 0.0f),

    BROOK_ELBAF("elbafcosmetics:brook_elbaf", 15, new int[]{2, 5, 4, 2}, 12,
            SoundEvents.ARMOR_EQUIP_LEATHER, 0.5f, 0.0f),

    JINBE_ELBAF("elbafcosmetics:jinbe_elbaf", 15, new int[]{2, 5, 4, 2}, 12,
            SoundEvents.ARMOR_EQUIP_LEATHER, 0.5f, 0.0f);

    private final String name;
    private final int durabilityMultiplier;
    private final int[] slotProtections;
    private final int enchantmentValue;
    private final SoundEvent equipSound;
    private final float toughness;
    private final float knockbackResistance;

    ModArmorMaterials(String name, int durabilityMultiplier, int[] slotProtections,
                       int enchantmentValue, SoundEvent equipSound, float toughness,
                       float knockbackResistance) {
        this.name = name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.slotProtections = slotProtections;
        this.enchantmentValue = enchantmentValue;
        this.equipSound = equipSound;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
    }

    public String getName() {
        return name;
    }

    public int getDurabilityForType(net.minecraft.world.item.ArmorItem.Type type) {
        int[] base = {13, 15, 16, 11};
        int idx = switch (type) {
            case BOOTS -> 0;
            case LEGGINGS -> 1;
            case CHESTPLATE -> 2;
            case HELMET -> 3;
            default -> 0;
        };
        return base[idx] * durabilityMultiplier;
    }

    public int getDefenseForType(net.minecraft.world.item.ArmorItem.Type type) {
        int idx = switch (type) {
            case BOOTS -> 0;
            case LEGGINGS -> 1;
            case CHESTPLATE -> 2;
            case HELMET -> 3;
            default -> 0;
        };
        return slotProtections[idx];
    }

    public int getEnchantmentValue() {
        return enchantmentValue;
    }

    public SoundEvent getEquipSound() {
        return equipSound;
    }

    public Ingredient getRepairIngredient() {
        return Ingredient.of(Items.LEATHER);
    }

    public String getTextureName(int layer) {
        return "elbafcosmetics:" + name + "_layer_" + layer;
    }

    public float getToughness() {
        return toughness;
    }

    public float getKnockbackResistance() {
        return knockbackResistance;
    }
}
