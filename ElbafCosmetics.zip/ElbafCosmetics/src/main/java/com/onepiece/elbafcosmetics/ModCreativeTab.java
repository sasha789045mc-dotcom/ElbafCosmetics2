package com.onepiece.elbafcosmetics;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTab {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ElbafCosmeticsMod.MODID);

    public static final RegistryObject<CreativeModeTab> ELBAF_TAB = TABS.register("elbaf_tab", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.elbafcosmetics"))
                    .icon(() -> new ItemStack(ModItems.LUFFY_ELBAF_HELMET.get()))
                    .displayItems((params, output) -> {
                        for (var item : ModItems.ALL_ITEMS) {
                            output.accept(item.get());
                        }
                    })
                    .build());
}
