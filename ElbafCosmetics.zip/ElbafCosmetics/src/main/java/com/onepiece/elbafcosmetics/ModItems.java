package com.onepiece.elbafcosmetics;

import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.List;

/**
 * Registers all cosmetic armor sets. 15 characters x 4 pieces (helmet,
 * chestplate, leggings, boots) = 60 items total.
 */
public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ElbafCosmeticsMod.MODID);

    public static final RegistryObject<Item> VEGAPUNK_HELMET = ITEMS.register("vegapunk_helmet",
            () -> new ArmorItem(ModArmorMaterials.VEGAPUNK, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> VEGAPUNK_CHESTPLATE = ITEMS.register("vegapunk_chestplate",
            () -> new ArmorItem(ModArmorMaterials.VEGAPUNK, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> VEGAPUNK_LEGGINGS = ITEMS.register("vegapunk_leggings",
            () -> new ArmorItem(ModArmorMaterials.VEGAPUNK, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> VEGAPUNK_BOOTS = ITEMS.register("vegapunk_boots",
            () -> new ArmorItem(ModArmorMaterials.VEGAPUNK, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> LOKI_HELMET = ITEMS.register("loki_helmet",
            () -> new ArmorItem(ModArmorMaterials.LOKI, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> LOKI_CHESTPLATE = ITEMS.register("loki_chestplate",
            () -> new ArmorItem(ModArmorMaterials.LOKI, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> LOKI_LEGGINGS = ITEMS.register("loki_leggings",
            () -> new ArmorItem(ModArmorMaterials.LOKI, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> LOKI_BOOTS = ITEMS.register("loki_boots",
            () -> new ArmorItem(ModArmorMaterials.LOKI, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> HAJRUDIN_HELMET = ITEMS.register("hajrudin_helmet",
            () -> new ArmorItem(ModArmorMaterials.HAJRUDIN, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> HAJRUDIN_CHESTPLATE = ITEMS.register("hajrudin_chestplate",
            () -> new ArmorItem(ModArmorMaterials.HAJRUDIN, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> HAJRUDIN_LEGGINGS = ITEMS.register("hajrudin_leggings",
            () -> new ArmorItem(ModArmorMaterials.HAJRUDIN, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> HAJRUDIN_BOOTS = ITEMS.register("hajrudin_boots",
            () -> new ArmorItem(ModArmorMaterials.HAJRUDIN, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> SAUL_HELMET = ITEMS.register("saul_helmet",
            () -> new ArmorItem(ModArmorMaterials.SAUL, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> SAUL_CHESTPLATE = ITEMS.register("saul_chestplate",
            () -> new ArmorItem(ModArmorMaterials.SAUL, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> SAUL_LEGGINGS = ITEMS.register("saul_leggings",
            () -> new ArmorItem(ModArmorMaterials.SAUL, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> SAUL_BOOTS = ITEMS.register("saul_boots",
            () -> new ArmorItem(ModArmorMaterials.SAUL, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> LUFFY_ELBAF_HELMET = ITEMS.register("luffy_elbaf_helmet",
            () -> new ArmorItem(ModArmorMaterials.LUFFY_ELBAF, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> LUFFY_ELBAF_CHESTPLATE = ITEMS.register("luffy_elbaf_chestplate",
            () -> new ArmorItem(ModArmorMaterials.LUFFY_ELBAF, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> LUFFY_ELBAF_LEGGINGS = ITEMS.register("luffy_elbaf_leggings",
            () -> new ArmorItem(ModArmorMaterials.LUFFY_ELBAF, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> LUFFY_ELBAF_BOOTS = ITEMS.register("luffy_elbaf_boots",
            () -> new ArmorItem(ModArmorMaterials.LUFFY_ELBAF, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> HARALD_HELMET = ITEMS.register("harald_helmet",
            () -> new ArmorItem(ModArmorMaterials.HARALD, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> HARALD_CHESTPLATE = ITEMS.register("harald_chestplate",
            () -> new ArmorItem(ModArmorMaterials.HARALD, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> HARALD_LEGGINGS = ITEMS.register("harald_leggings",
            () -> new ArmorItem(ModArmorMaterials.HARALD, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> HARALD_BOOTS = ITEMS.register("harald_boots",
            () -> new ArmorItem(ModArmorMaterials.HARALD, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> ZORO_ELBAF_HELMET = ITEMS.register("zoro_elbaf_helmet",
            () -> new ArmorItem(ModArmorMaterials.ZORO_ELBAF, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> ZORO_ELBAF_CHESTPLATE = ITEMS.register("zoro_elbaf_chestplate",
            () -> new ArmorItem(ModArmorMaterials.ZORO_ELBAF, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> ZORO_ELBAF_LEGGINGS = ITEMS.register("zoro_elbaf_leggings",
            () -> new ArmorItem(ModArmorMaterials.ZORO_ELBAF, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> ZORO_ELBAF_BOOTS = ITEMS.register("zoro_elbaf_boots",
            () -> new ArmorItem(ModArmorMaterials.ZORO_ELBAF, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> NAMI_ELBAF_HELMET = ITEMS.register("nami_elbaf_helmet",
            () -> new ArmorItem(ModArmorMaterials.NAMI_ELBAF, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> NAMI_ELBAF_CHESTPLATE = ITEMS.register("nami_elbaf_chestplate",
            () -> new ArmorItem(ModArmorMaterials.NAMI_ELBAF, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> NAMI_ELBAF_LEGGINGS = ITEMS.register("nami_elbaf_leggings",
            () -> new ArmorItem(ModArmorMaterials.NAMI_ELBAF, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> NAMI_ELBAF_BOOTS = ITEMS.register("nami_elbaf_boots",
            () -> new ArmorItem(ModArmorMaterials.NAMI_ELBAF, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> ROBIN_ELBAF_HELMET = ITEMS.register("robin_elbaf_helmet",
            () -> new ArmorItem(ModArmorMaterials.ROBIN_ELBAF, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> ROBIN_ELBAF_CHESTPLATE = ITEMS.register("robin_elbaf_chestplate",
            () -> new ArmorItem(ModArmorMaterials.ROBIN_ELBAF, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> ROBIN_ELBAF_LEGGINGS = ITEMS.register("robin_elbaf_leggings",
            () -> new ArmorItem(ModArmorMaterials.ROBIN_ELBAF, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> ROBIN_ELBAF_BOOTS = ITEMS.register("robin_elbaf_boots",
            () -> new ArmorItem(ModArmorMaterials.ROBIN_ELBAF, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> CHOPPER_ELBAF_HELMET = ITEMS.register("chopper_elbaf_helmet",
            () -> new ArmorItem(ModArmorMaterials.CHOPPER_ELBAF, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> CHOPPER_ELBAF_CHESTPLATE = ITEMS.register("chopper_elbaf_chestplate",
            () -> new ArmorItem(ModArmorMaterials.CHOPPER_ELBAF, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> CHOPPER_ELBAF_LEGGINGS = ITEMS.register("chopper_elbaf_leggings",
            () -> new ArmorItem(ModArmorMaterials.CHOPPER_ELBAF, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> CHOPPER_ELBAF_BOOTS = ITEMS.register("chopper_elbaf_boots",
            () -> new ArmorItem(ModArmorMaterials.CHOPPER_ELBAF, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> USOPP_ELBAF_HELMET = ITEMS.register("usopp_elbaf_helmet",
            () -> new ArmorItem(ModArmorMaterials.USOPP_ELBAF, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> USOPP_ELBAF_CHESTPLATE = ITEMS.register("usopp_elbaf_chestplate",
            () -> new ArmorItem(ModArmorMaterials.USOPP_ELBAF, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> USOPP_ELBAF_LEGGINGS = ITEMS.register("usopp_elbaf_leggings",
            () -> new ArmorItem(ModArmorMaterials.USOPP_ELBAF, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> USOPP_ELBAF_BOOTS = ITEMS.register("usopp_elbaf_boots",
            () -> new ArmorItem(ModArmorMaterials.USOPP_ELBAF, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> SANJI_ELBAF_HELMET = ITEMS.register("sanji_elbaf_helmet",
            () -> new ArmorItem(ModArmorMaterials.SANJI_ELBAF, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> SANJI_ELBAF_CHESTPLATE = ITEMS.register("sanji_elbaf_chestplate",
            () -> new ArmorItem(ModArmorMaterials.SANJI_ELBAF, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> SANJI_ELBAF_LEGGINGS = ITEMS.register("sanji_elbaf_leggings",
            () -> new ArmorItem(ModArmorMaterials.SANJI_ELBAF, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> SANJI_ELBAF_BOOTS = ITEMS.register("sanji_elbaf_boots",
            () -> new ArmorItem(ModArmorMaterials.SANJI_ELBAF, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> FRANKY_ELBAF_HELMET = ITEMS.register("franky_elbaf_helmet",
            () -> new ArmorItem(ModArmorMaterials.FRANKY_ELBAF, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> FRANKY_ELBAF_CHESTPLATE = ITEMS.register("franky_elbaf_chestplate",
            () -> new ArmorItem(ModArmorMaterials.FRANKY_ELBAF, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> FRANKY_ELBAF_LEGGINGS = ITEMS.register("franky_elbaf_leggings",
            () -> new ArmorItem(ModArmorMaterials.FRANKY_ELBAF, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> FRANKY_ELBAF_BOOTS = ITEMS.register("franky_elbaf_boots",
            () -> new ArmorItem(ModArmorMaterials.FRANKY_ELBAF, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> BROOK_ELBAF_HELMET = ITEMS.register("brook_elbaf_helmet",
            () -> new ArmorItem(ModArmorMaterials.BROOK_ELBAF, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> BROOK_ELBAF_CHESTPLATE = ITEMS.register("brook_elbaf_chestplate",
            () -> new ArmorItem(ModArmorMaterials.BROOK_ELBAF, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> BROOK_ELBAF_LEGGINGS = ITEMS.register("brook_elbaf_leggings",
            () -> new ArmorItem(ModArmorMaterials.BROOK_ELBAF, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> BROOK_ELBAF_BOOTS = ITEMS.register("brook_elbaf_boots",
            () -> new ArmorItem(ModArmorMaterials.BROOK_ELBAF, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> JINBE_ELBAF_HELMET = ITEMS.register("jinbe_elbaf_helmet",
            () -> new ArmorItem(ModArmorMaterials.JINBE_ELBAF, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> JINBE_ELBAF_CHESTPLATE = ITEMS.register("jinbe_elbaf_chestplate",
            () -> new ArmorItem(ModArmorMaterials.JINBE_ELBAF, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> JINBE_ELBAF_LEGGINGS = ITEMS.register("jinbe_elbaf_leggings",
            () -> new ArmorItem(ModArmorMaterials.JINBE_ELBAF, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> JINBE_ELBAF_BOOTS = ITEMS.register("jinbe_elbaf_boots",
            () -> new ArmorItem(ModArmorMaterials.JINBE_ELBAF, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));

    public static final List<RegistryObject<Item>> ALL_ITEMS = List.of(
            VEGAPUNK_HELMET,
            VEGAPUNK_CHESTPLATE,
            VEGAPUNK_LEGGINGS,
            VEGAPUNK_BOOTS,
            LOKI_HELMET,
            LOKI_CHESTPLATE,
            LOKI_LEGGINGS,
            LOKI_BOOTS,
            HAJRUDIN_HELMET,
            HAJRUDIN_CHESTPLATE,
            HAJRUDIN_LEGGINGS,
            HAJRUDIN_BOOTS,
            SAUL_HELMET,
            SAUL_CHESTPLATE,
            SAUL_LEGGINGS,
            SAUL_BOOTS,
            LUFFY_ELBAF_HELMET,
            LUFFY_ELBAF_CHESTPLATE,
            LUFFY_ELBAF_LEGGINGS,
            LUFFY_ELBAF_BOOTS,
            HARALD_HELMET,
            HARALD_CHESTPLATE,
            HARALD_LEGGINGS,
            HARALD_BOOTS,
            ZORO_ELBAF_HELMET,
            ZORO_ELBAF_CHESTPLATE,
            ZORO_ELBAF_LEGGINGS,
            ZORO_ELBAF_BOOTS,
            NAMI_ELBAF_HELMET,
            NAMI_ELBAF_CHESTPLATE,
            NAMI_ELBAF_LEGGINGS,
            NAMI_ELBAF_BOOTS,
            ROBIN_ELBAF_HELMET,
            ROBIN_ELBAF_CHESTPLATE,
            ROBIN_ELBAF_LEGGINGS,
            ROBIN_ELBAF_BOOTS,
            CHOPPER_ELBAF_HELMET,
            CHOPPER_ELBAF_CHESTPLATE,
            CHOPPER_ELBAF_LEGGINGS,
            CHOPPER_ELBAF_BOOTS,
            USOPP_ELBAF_HELMET,
            USOPP_ELBAF_CHESTPLATE,
            USOPP_ELBAF_LEGGINGS,
            USOPP_ELBAF_BOOTS,
            SANJI_ELBAF_HELMET,
            SANJI_ELBAF_CHESTPLATE,
            SANJI_ELBAF_LEGGINGS,
            SANJI_ELBAF_BOOTS,
            FRANKY_ELBAF_HELMET,
            FRANKY_ELBAF_CHESTPLATE,
            FRANKY_ELBAF_LEGGINGS,
            FRANKY_ELBAF_BOOTS,
            BROOK_ELBAF_HELMET,
            BROOK_ELBAF_CHESTPLATE,
            BROOK_ELBAF_LEGGINGS,
            BROOK_ELBAF_BOOTS,
            JINBE_ELBAF_HELMET,
            JINBE_ELBAF_CHESTPLATE,
            JINBE_ELBAF_LEGGINGS,
            JINBE_ELBAF_BOOTS
    );
}
